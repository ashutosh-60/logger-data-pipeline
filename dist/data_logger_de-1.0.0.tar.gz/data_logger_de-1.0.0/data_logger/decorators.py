import time
import functools
# Import the structural contracts from your existing metrics and lineage modules
from data_logger.metrics import ProcessMetrics
from data_logger import get_logger

logger = get_logger("DE_Decorator_Engine")

def log_task(task_name: str, track_time: bool = True, track_stats: bool = False):
    """
    A clean, explicit decorator factory.
    Allows the developer to select exactly what telemetry to capture.
    """
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            metadata = {}
            
            # 1. Handle Execution Timing if requested
            start_time = time.perf_counter() if track_time else None
            
            logger.info(f"Task '{task_name}' initialized.")
            
            try:
                # Execute the actual pipeline function logic
                result = func(*args, **kwargs)
                
                # 2. Handle Runtime Timing Computation on Success
                if track_time and start_time is not None:
                    duration = time.perf_counter() - start_time
                    metadata["task_timing"] = {
                        "task_name": task_name,
                        "duration_seconds": round(duration, 4)
                    }
                
                # 3. Handle Operational Stats Interception if requested
                if track_stats:
                    # If the user passed a ProcessMetrics object or dictionary
                    if isinstance(result, ProcessMetrics):
                        metadata["operational_metrics"] = result.to_dict()
                    elif isinstance(result, dict):
                        metadata["operational_metrics"] = result
                
                # Log completion with the cleanly built metadata payload
                if metadata:
                    logger.info(f"Task '{task_name}' completed successfully.", extra={"metadata": metadata})
                else:
                    logger.info(f"Task '{task_name}' completed successfully.")
                    
                return result
                
            except Exception as e:
                logger.error(f"Task '{task_name}' failed. Error: {str(e)}")
                raise e
                
        return wrapper
    return decorator

def log_task_by_ref(task_name: str, track_time: bool = True, track_stats: bool = False):
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            metadata = {}
            start_time = time.perf_counter() if track_time else None
            
            # Context injection: look for an explicit tracking dictionary in kwargs
            # If the developer didn't pass one, create a temporary dictionary reference hook
            if "log_ctx" not in kwargs:
                kwargs["log_ctx"] = {}
                
            logger.info(f"Task '{task_name}' initialized.")
            
            try:
                # Execute the pipeline step
                result = func(*args, **kwargs)
                
                # Post-Execution: Harvest the values bound to the tracking context hook
                if track_stats and kwargs.get("log_ctx"):
                    metadata["operational_metrics"] = kwargs["log_ctx"]
                
                if track_time and start_time is not None:
                    duration = time.perf_counter() - start_time
                    metadata["task_timing"] = {
                        "task_name": task_name,
                        "duration_seconds": round(duration, 4)
                    }
                
                if metadata:
                    logger.info(f"Task '{task_name}' completed successfully.", extra={"metadata": metadata})
                else:
                    logger.info(f"Task '{task_name}' completed successfully.")
                
                # Returns standard data unmodified
                return result
                
            except Exception as e:
                logger.error(f"Task '{task_name}' failed. Error: {str(e)}")
                raise e
        return wrapper
    return decorator