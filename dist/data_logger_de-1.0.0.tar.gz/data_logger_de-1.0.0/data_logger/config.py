from dataclasses import dataclass
from typing import Optional

@dataclass
class LoggerConfig:
    """
    Configuration model to toggle destinations and inject custom schemas.
    """
    enable_console: bool = True
    enable_sql: bool = False
    enable_delta: bool = False
    include_lineage: bool = True # <-- New lineage feature opt-out toggle
    custom_schema: Optional[str] = None
    
    # Placeholders for future connection strings
    sql_connection_string: Optional[str] = None
    delta_file_path: Optional[str] = None