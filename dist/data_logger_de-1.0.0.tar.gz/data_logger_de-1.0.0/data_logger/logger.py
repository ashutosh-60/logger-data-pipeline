import logging
from contextlib import contextmanager
import time
from datetime import datetime
from .config import LoggerConfig
from .formatters import get_json_formatter
from .lineage import LineageFilter

def get_logger(name: str, config: LoggerConfig = None) -> logging.Logger:
    """
    Factory function to assemble and return a configured logger instance[cite: 24, 25].
    """
    if config is None:
        config = LoggerConfig()

    logger = logging.getLogger(name)
    
    # Clear existing handlers to prevent duplicate logs in interactive sessions
    if logger.hasHandlers():
        logger.handlers.clear()
        
    logger.setLevel(logging.INFO)

    # Automatically attach the LineageFilter if enabled [cite: 136]
    if config.include_lineage:
        logger.addFilter(LineageFilter())

    # Dynamically build the JSON schema using the list-loop formatter [cite: 136]
    formatter = get_json_formatter(
        custom_schema=config.custom_schema, 
        include_lineage=config.include_lineage
    )

    if config.enable_console:
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)

    return logger


@contextmanager
def timer_scope(scope_name: str, logger_name: str = "inline_runner"):
    """
    Context manager to autonomously measure and log execution duration 
    for procedural or inline data blocks[cite: 209, 210].
    """
    
    logger = get_logger(logger_name)
    start_wall = datetime.utcnow().isoformat()
    start_perf = time.perf_counter()
    logger.info(
        f"Started inline block '{scope_name}'.", 
        extra={"scope_timing": {"start_time": start_wall}}
    )
    try:
        yield
        end_wall = datetime.utcnow().isoformat()
        duration = time.perf_counter() - start_perf
        
        logger.info(
            f"Finished inline block '{scope_name}'.",
            extra={
                "scope_timing": {
                    "start_time": start_wall,
                    "end_time": end_wall,
                    "duration_seconds": round(duration, 4)
                }
            }
        )
    except Exception as e:
        end_wall = datetime.utcnow().isoformat()
        duration = time.perf_counter() - start_perf
        logger.error(
            f"Inline block '{scope_name}' failed: {str(e)}",
            extra={
                "scope_timing": {
                    "start_time": start_wall,
                    "end_time": end_wall,
                    "duration_seconds": round(duration, 4)
                }
            }
        )
        raise