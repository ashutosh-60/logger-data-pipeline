import contextvars
import uuid
from logging import Filter, LogRecord
from typing import Optional

# Initialize context variables for tracing global state
# A unique tracking string that anchors the entire pipeline run
current_run_id: contextvars.ContextVar[str] = contextvars.ContextVar("current_run_id", default="")
# The identifier of the operational task that triggered this step
current_upstream_id: contextvars.ContextVar[str] = contextvars.ContextVar("current_upstream_id", default="")
# The identifier of the specific active block running
current_task_id: contextvars.ContextVar[str] = contextvars.ContextVar("current_task_id", default="")

def initialize_pipeline_context(run_id: Optional[str] = None) -> str:
    """Initializes the top-level execution run ID, generating a GUID by default."""
    rid = run_id if run_id else str(uuid.uuid4())
    current_run_id.set(rid)
    return rid

class LineageFilter(Filter):
    """
    Autonomously injects distributed tracing metrics from contextvars
    into the logging record metadata pipeline.
    """
    def filter(self, record: LogRecord) -> bool:
        # Dynamically map context fields directly to record variables
        record.run_id = current_run_id.get()
        record.upstream_id = current_upstream_id.get()
        record.task_id = current_task_id.get()
        return True